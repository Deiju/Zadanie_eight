package com.example.myapplication

import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import android.widget.EditText
import android.widget.Toast
import kotlin.collections.Collection

class UserLogin : AppCompatActivity() {

    private val APP_PREFERENCES = "settings"
    private val pref_email="email"
    private val pref_login="login"
    private val pref_psswd="psswd"

    lateinit var login: EditText
    lateinit var pass: EditText
    lateinit var email: EditText
    lateinit var pref: SharedPreferences

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_user_login)
        email = findViewById(R.id.Email)
        login = findViewById(R.id.Login)
        pass = findViewById(R.id.Pass)
        pref = getSharedPreferences(APP_PREFERENCES, MODE_PRIVATE)
    }

    fun setPreferences(view: View) {
            val Psswd = pass.text.toString()
            val Login = login.text.toString()
            val Email = email.text.toString()
            if (Psswd.isNotEmpty() && Login.isNotEmpty() && Email.isNotEmpty()) {
                val prefEditor = pref.edit()
                prefEditor.putString(pref_email, Email)
                prefEditor.putString(pref_login, Login)
                prefEditor.putString(pref_psswd, Psswd)
                prefEditor.apply()
            } else {
                Toast.makeText(applicationContext, "Обнаружены пустые поля", Toast.LENGTH_SHORT).show()
            }
        }
        fun getPreferences(view: View) {
        val enteredEmail = email.text.toString()
        val enteredLogin=login.text.toString()
        val enteredPsswd=pass.text.toString()
        val savedEmail=pref.getString(pref_email,"")
        val savedLogin=pref.getString(pref_login,"")
        val savedPsswd=pref.getString(pref_psswd,"")
        if ((enteredPsswd.isNotEmpty() && enteredLogin.isNotEmpty()) || (enteredPsswd.isNotEmpty() && enteredEmail.isNotEmpty())) {
            if (enteredPsswd == savedPsswd && enteredEmail == savedEmail) {
                email.setText(savedEmail)
                login.setText(savedLogin)
                pass.setText(savedPsswd)
                var intent = Intent(this, com.example.myapplication.Collection::class.java)
                startActivity(intent)
            } else {
                Toast.makeText(
                    applicationContext,
                    "Введёные неверные данные для авторизации",
                    Toast.LENGTH_SHORT
                ).show()
            }
        }
    }
}