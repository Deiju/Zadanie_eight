package com.example.myapplication

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.MenuItem
import android.view.View
import android.widget.PopupMenu
import com.example.myapplication.databinding.ActivityCollectionBinding

class Collection : AppCompatActivity() {
    lateinit var bindingClass:ActivityCollectionBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        bindingClass = ActivityCollectionBinding.inflate((layoutInflater))
        super.onCreate(savedInstanceState)
        setContentView(bindingClass.root)
    }
    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.menu_edittask -> {
                var intent = Intent(this, EditTask::class.java)
                startActivity(intent)
                finish()
                return true
            }
            R.id.menu_task -> {
                var intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
                return true
            }
        }
        return false
    }
    fun showMenu(view: View){
        val popupmenu = PopupMenu(this, view)
        popupmenu.inflate(R.menu.menu_main)

        popupmenu.setOnMenuItemClickListener { item ->
            onOptionsItemSelected(item)
        }
        popupmenu.show()
    }
}